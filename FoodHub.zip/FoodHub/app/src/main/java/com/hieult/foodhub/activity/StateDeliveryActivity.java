package com.hieult.foodhub.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.hieult.foodhub.R;

public class StateDeliveryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state_delivery);
    }
}