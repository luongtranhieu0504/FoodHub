package com.hieult.foodhub.Interface;

public interface ItemClickListener {
    void onItemClick(int position);

}
