package com.hieult.foodhub.activity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hieult.foodhub.R;
import com.mapbox.api.directions.v5.models.DirectionsResponse;
import com.mapbox.api.directions.v5.models.DirectionsRoute;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.maps.Style;
import com.mapbox.mapboxsdk.maps.SupportMapFragment;
import com.mapbox.mapboxsdk.plugins.annotation.LineManager;
import com.mapbox.mapboxsdk.plugins.annotation.SymbolManager;
import com.mapbox.mapboxsdk.plugins.annotation.SymbolOptions;
import com.mapbox.services.android.navigation.ui.v5.NavigationView;
import com.mapbox.services.android.navigation.ui.v5.NavigationViewOptions;
import com.mapbox.services.android.navigation.ui.v5.OnNavigationReadyCallback;
import com.mapbox.services.android.navigation.ui.v5.route.NavigationMapRoute;
import com.mapbox.services.android.navigation.v5.navigation.NavigationRoute;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MapDeliveryActivity extends FragmentActivity implements OnMapReadyCallback {


    private DatabaseReference databaseReference;
    private MapView mapView;
    private MapboxMap mapboxMap;
    private SymbolManager symbolManager;
    private LineManager lineManager;

    private LatLng fixedDestinationLatLng;
    private DirectionsRoute currentRoute;
    private NavigationView navigationView;
    private NavigationMapRoute navigationMapRoute;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Mapbox.getInstance(this, getString(R.string.mapbox_access_token));
        setContentView(R.layout.activity_map_delivery);
        mapView = findViewById(R.id.mapView);
        databaseReference = FirebaseDatabase.getInstance().getReference().child("addAddress").child("Home Address");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapFragment);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
    }
    @Override
    public void onMapReady(@NonNull MapboxMap mapboxMap) {
        this.mapboxMap = mapboxMap;
        mapboxMap.setStyle(Style.MAPBOX_STREETS, new Style.OnStyleLoaded() {
            @Override
            public void onStyleLoaded(@NonNull Style style) {
                // Initialize SymbolManager
                symbolManager = new SymbolManager(mapView, mapboxMap, style);
                symbolManager.setIconAllowOverlap(true);
                symbolManager.setTextAllowOverlap(true);
                // Initialize LineManager
                // Thêm điểm cố định và đường nối
                addFixedDestinationMarker();
                fetchDestinationFromFirebase();
                // Di chuyển và zoom vào khu vực có các điểm
                LatLng fixedDestinationLatLng = new LatLng(40.742352, -74.006210);
                CameraPosition position = new CameraPosition.Builder()
                        .target(fixedDestinationLatLng)
                        .zoom(10)
                        .build();
                mapboxMap.animateCamera(CameraUpdateFactory.newCameraPosition(position), 5000);
            }
        });
    }


    private void addFixedDestinationMarker() {
        // Thêm điểm cố định
        fixedDestinationLatLng = new LatLng(40.742352, -74.006210);
        symbolManager.create(new SymbolOptions()
                .withLatLng(new LatLng(fixedDestinationLatLng.getLatitude(), fixedDestinationLatLng.getLongitude()))
                .withIconImage("pin-red")
                .withIconSize(1.0f)
                .withIconColor("red"));
    }

    private void fetchDestinationFromFirebase() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String streets = dataSnapshot.child("street").getValue(String.class);
                    String city = dataSnapshot.child("city").getValue(String.class);
                    String address = streets + city;
                    Log.d("MyData", "showAddress: " + address);
                    Log.d("MyData", "showStreet: " + streets);
                    Log.d("MyData", "showCity: " + city);
                    // Chuyển địa chỉ thành tọa độ và thêm vào bản đồ
                    addFirebaseDestinationMarker(address);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MapDeliveryActivity.this, "Error fetching data from Firebase", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addFirebaseDestinationMarker(String address) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocationName(address, 1);
            if (!addresses.isEmpty()) {
                double destinationLatitude = addresses.get(0).getLatitude();
                double destinationLongitude = addresses.get(0).getLongitude();
                LatLng destinationLatLng = new LatLng(destinationLatitude, destinationLongitude);
                Log.d("MyData", "showAddress: " + destinationLatLng);
                if (destinationLatLng != null) {
//                    symbolManager.create(new SymbolOptions()
//                            .withLatLng(new LatLng(destinationLatLng.getLatitude(), destinationLatLng.getLongitude()))
//                            .withIconImage("pin-red")
//                            .withIconSize(1.0f)
//                            .withIconColor("blue"));
//                    LineOptions lineOptions = new LineOptions()
//                            .withLatLngs(Arrays.asList(
//                                    new LatLng(fixedDestinationLatLng.getLatitude(), fixedDestinationLatLng.getLongitude()),
//                                    new LatLng(destinationLatLng.getLatitude(), destinationLatLng.getLongitude())
//                            ))
//                            .withLineColor("green")
//                            .withLineWidth(3f);
                    startNavigation(fixedDestinationLatLng,destinationLatLng);
                } else {
                    Toast.makeText(MapDeliveryActivity.this, "Destination coordinates are null", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MapDeliveryActivity.this, "Error converting address to coordinates", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MapDeliveryActivity.this, "Error converting address to coordinates", Toast.LENGTH_SHORT).show();
        }
    }
    private void startNavigation(LatLng origin, LatLng destination) {
        // Lấy chỉ đường từ Mapbox Directions API
        getRoute(origin, destination);
    }
    private void getRoute(LatLng origin, LatLng destination) {
        NavigationRoute.builder(this)
                .accessToken(getString(R.string.mapbox_access_token))
                .origin(Point.fromLngLat(origin.getLongitude(), origin.getLatitude()))
                .destination(Point.fromLngLat(destination.getLongitude(), destination.getLatitude()))
                .build()
                .getRoute(new Callback<DirectionsResponse>() {
                    @Override
                    public void onResponse(Call<DirectionsResponse> call, Response<DirectionsResponse> response) {
                        if (response.body() != null && response.body().routes().size() > 0) {
                            currentRoute = response.body().routes().get(0);
                            if (navigationMapRoute != null) {
                                navigationMapRoute.updateRouteArrowVisibilityTo(false);
                            } else {
                                navigationMapRoute = new NavigationMapRoute(null, mapView, mapboxMap);
                            }
                            navigationMapRoute.addRoute(currentRoute);
                        }
                    }

                    @Override
                    public void onFailure(Call<DirectionsResponse> call, Throwable t) {
                        // Handle failure
                    }
                });
    }
    private void startNavigation() {
        NavigationViewOptions.Builder optionsBuilder = NavigationViewOptions.builder()
                .directionsRoute(currentRoute)
                .shouldSimulateRoute(false);

        NavigationView navigationView = new NavigationView(this);
        navigationView.onCreate(null);
        navigationView.initialize((OnNavigationReadyCallback) optionsBuilder.build());
    }



    @Override
    protected void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}

