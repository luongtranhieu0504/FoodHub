buildscript {
    repositories {
        google()
        mavenCentral()
        maven {
            url = uri("https://api.mapbox.com/downloads/v2/releases/maven")
            credentials {
                username = "mapbox"
                password = project.properties["MAPBOX_DOWNLOADS_TOKEN"] as String
            }
        }
    }
    dependencies {
        classpath("com.google.gms:google-services:4.4.0")
    }
}


plugins {
    id("com.android.application") version "8.0.0" apply false
}